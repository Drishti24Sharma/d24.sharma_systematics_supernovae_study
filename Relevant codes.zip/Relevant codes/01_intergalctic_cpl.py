#___________________________CPL_CALIBRATION____________________________________#
#import mpi4py
import os
os.environ["OMP_NUM_THREADS"] = "1"
import time
import numpy as np
import scipy.optimize as opt
import scipy.stats
import scipy.linalg as la
from scipy import constants
import matplotlib.pyplot as pl
import corner
import emcee
from matplotlib.ticker import MaxNLocator
#from emcee.utils import MPIPool
import sys
import tqdm
#from emcee.utils import MPIPool
from new02_model import *
import matplotlib
import matplotlib.pyplot as plt
import pandas as pd
import getdist
from getdist import plots, MCSamples
output_dir = 'NEW_01_intergalactic_cpl_results'
os.makedirs(output_dir,exist_ok= True )

zdesi, meandesi = np.loadtxt('data/desi_dr2_2025_gaussian_bao_ALL_GCcomb_mean.txt', usecols=(0, 1), unpack=True)
Ndesi = len(zdesi)
covdesi_dr2 = np.loadtxt('data/desi_dr2_2025_gaussian_bao_ALL_GCcomb_cov.txt')[:Ndesi, :Ndesi]
covinvd2 = np.linalg.inv(covdesi_dr2)

covar = os.path.join("data/Pantheon+SH0ES_STAT+SYS.cov")
data = pd.read_csv('data/Pantheon+SH0ES.dat',sep=r'\s+')
cov  = np.loadtxt('data/Pantheon+SH0ES_STAT+SYS.cov')
covarray = cov[1:len(cov)]    
covmat = covarray.reshape(1701,1701) 

z_cmb = data['zHD']
mu = data['MU_SH0ES']
m = data['m_b_corr']
origlen = len(data)

ww = (data['zHD']>0.01) 
zCMB = data['zHD'][ww] 
zHEL = data['zHEL'][ww]
mu_obs = data['MU_SH0ES'][ww]
m_obs = data['m_b_corr'][ww]
is_calibrator = data['IS_CALIBRATOR'][ww]
cepheid_distance = data['CEPH_DIST'][ww]

f = open(covar)
line = f.readline()
n = int(len(zCMB))
C = np.zeros((n,n))
ii = -1
jj = -1
mine = 999
maxe = -999
for i in range(origlen):
    jj = -1
    if ww[i]:
        ii += 1
    for j in range(origlen):
        if ww[j]:
            jj += 1
        val = float(f.readline())
        if ww[i]:
            if ww[j]:
                C[ii,jj] = val
f.close()

newcov = C
covariance = np.array(newcov)
inv_cov = np.linalg.inv(covariance)

zcmb = zCMB.to_numpy()
zhel = zHEL.to_numpy()

#--------Simulating data----------#
clas_sn = CPL(Om0=0.3, w0=-1., wa=0)

Dl_sim = np.array([clas_sn.D_L_z(z) for z in zcmb])
mu_sim = 5.* np.log10(Dl_sim) + 25

clas_bao = CPL(h=0.7, rd=147.09, Om0=0.3, w0=-1., wa=0.)

dist_bao = np.array([clas_bao.dvrd(0.295),
        clas_bao.dmrd(0.510),
        clas_bao.dhrd(0.510),
        clas_bao.dmrd(0.706),
        clas_bao.dhrd(0.706),
        clas_bao.dmrd(0.934),
        clas_bao.dhrd(0.934),
        clas_bao.dmrd(1.321),
        clas_bao.dhrd(1.321),
        clas_bao.dmrd(1.484),
        clas_bao.dhrd(1.484),
        clas_bao.dmrd(2.330),
        clas_bao.dhrd(2.330)])



def chiPanthSN(h, rd, Om0, w0, wa):
    M=0.
    clas = CPL(h, rd, Om0, w0, wa)
    x = np.vectorize(clas.luminosity_distance_z) 
    mod = 5.* np.log10((1.+zHEL)/(1.+zCMB) * x(zCMB) * c_kms/h) + 25.
    delta = np.array(mu_sim - mod - M)
    A = np.sum(delta.T @ inv_cov @ delta)
    B = np.sum(delta @ inv_cov)
    C = np.sum(inv_cov)
    return A #- B**2 / C

def delta_mu_igdust(z, h, rd, Om0, w0, wa): # Omega_dust=5e-6, gamma=-1., kappa_lambda=1.54e4):
    # Constants
    c = 2.99792458e10  # cm/s
    H0 = h * 100 * 1e5 / 3.086e24  # s^-1 (convert km/s/Mpc to s^-1)
    G = 6.67430e-8  # cm^3 g^-1 s^-2
    Omega_dust = 5e-6
    gamma = -1
    kappa_lambda = 1.54e4
    # Integrand for tau(z)
    def integrand(zp):
        #E_z = CPL(h, 147.09, Om0, w0, wa).hubble_normalized_z(zp)
        E_z = CPL(h, rd, Om0, w0, wa).hubble_normalized_z(zp)
        return (1 + zp)**(gamma - 1) / E_z

    tau = np.array([
        (3 * c * H0 * Omega_dust * kappa_lambda) / (8 * np.pi * G) * quad(integrand, 0, zi)[0]
        for zi in np.atleast_1d(z)
    ])
    return 1.086 * tau  # Convert tau to mag offset Δμ = 1.086 * τ

def chiPanthSN_M(h, rd, Om0, w0, wa):

    M = delta_mu_igdust(zCMB, h, rd, Om0, w0, wa)# Omega_dust=5e-6) # Apply intergalactic dust correction

    clas = CPL(h, rd, Om0, w0, wa)
    x = np.vectorize(clas.luminosity_distance_z) 
    mod = 5.* np.log10((1.+zHEL)/(1.+zCMB) * x(zCMB) * c_kms/h) + 25.
    delta = np.array(mu_sim - mod+ M)
    A = np.sum(delta.T @ inv_cov @ delta)
    B = np.sum(delta @ inv_cov)
    C = np.sum(inv_cov)
    return A # - B**2 / C


def chidesi(h, rd, Om0, w0, wa):
    clas = CPL(h, rd, Om0, w0, wa)
    zz12 = np.array([clas.dvrd(0.295),
        clas.dmrd(0.510),
        clas.dhrd(0.510),
        clas.dmrd(0.706),
        clas.dhrd(0.706),
        clas.dmrd(0.934),
        clas.dhrd(0.934),
        clas.dmrd(1.321),
        clas.dhrd(1.321),
        clas.dmrd(1.484),
        clas.dhrd(1.484),
        clas.dmrd(2.330),
        clas.dhrd(2.330),
    ]) -  dist_bao
    return np.dot(zz12, np.dot(covinvd2, zz12))

def chird(rd):
    return (rd - 147.09)**2/0.27**2

def chiom(Om0):
    return (Om0 - 0.3)**2/0.007**2

def chi2(h, rd, Om0, w0, wa):
    return chidesi(h, rd, Om0, w0, wa) + chiPanthSN(h, rd, Om0, w0, wa) + chird(rd) + chiom(Om0)

def lnlike(h, rd, Om0, w0, wa):
    return -0.5 * chi2(h, rd, Om0, w0, wa) 

def lnprior(h, rd, Om0, w0, wa):
    if 0.3 < h < 1.2 and 100. < rd < 200. and 0.0 < Om0 < 1. and -3 < w0 < 1. and -3 < wa < 2. :
        return 0.0
    return -np.inf

def lnprob(theta):
    h, rd, Om0, w0, wa = theta
    lp = lnprior(h, rd, Om0, w0, wa)
    if not np.isfinite(lp):
        return -np.inf
    ll = lnlike(h, rd, Om0, w0, wa)
    return lp + ll if np.isfinite(ll) and not np.isnan(ll) and not np.iscomplex(ll) else -np.inf

def ff(theta): return -2. * lnprob(theta)
def lnp(theta): return lnprob(theta)

print('chi2 is',chi2(0.7,147.09,0.3,-1.,0.))

def chi2_M(h, rd, Om0, w0, wa):
    return chidesi(h, rd, Om0, w0, wa) + chiPanthSN_M(h, rd, Om0, w0, wa) + chird(rd) + chiom(Om0)

def lnlike_M(h, rd, Om0, w0, wa):
    return -0.5 * chi2_M(h, rd, Om0, w0, wa)

def lnprob_M(theta):
    h, rd, Om0, w0, wa = theta
    lp = lnprior(h, rd, Om0, w0, wa)
    if not np.isfinite(lp):
        return -np.inf
    ll = lnlike_M(h, rd, Om0, w0, wa)
    return lp + ll if np.isfinite(ll) and not np.isnan(ll) and not np.iscomplex(ll) else -np.inf

def ff_M(theta): return -2. * lnprob_M(theta)
def lnp_M(theta): return lnprob_M(theta)

print('chi2_M is', chi2_M(0.7,147.09,0.3,-1.,0.))

# Main block
if __name__ == '__main__':
    import multiprocessing
    from multiprocessing import Pool
    multiprocessing.set_start_method('spawn')

    result_no_offset = opt.minimize(ff, [0.7, 147.09, 0.3, -1., 0.])
    h_ml_no_offset, rd_ml_no_offset, Om0_ml_no_offset, w0_ml_no_offset, wa_ml_no_offset = result_no_offset['x']
    print("""Maximum likelihood result(no offset):
        #      h = {0} (truth: {1})
        #     rd = {2} (truth: {3})
        #     Om = {4} (truth: {5})
        #     w0 = {6} (truth: {7})
        #     wa = {8} (truth: {9})""".format(h_ml_no_offset, 0.7, rd_ml_no_offset, 147.09, Om0_ml_no_offset, 0.3, w0_ml_no_offset, -1., wa_ml_no_offset, 0.))


    result_offset = opt.minimize(ff_M, [0.7, 147.09, 0.3, -1., 0.])
    h_ml_offset, rd_ml_offset, Om0_ml_offset, w0_ml_offset, wa_ml_offset = result_offset['x']
    print("""Maximum likelihood result(offset):
        #      h = {0} (truth: {1})
        #     rd = {2} (truth: {3})
        #     Om = {4} (truth: {5})
        #     w0 = {6} (truth: {7})
        #     wa = {8} (truth: {9})""".format(h_ml_offset, 0.7, rd_ml_offset, 147.09, Om0_ml_offset, 0.3, w0_ml_offset, -1., wa_ml_offset, 0.))

    ndim, nwalkers =5, 200
    
    pos_no_offset = [np.array([0.7,147.09,0.3,-1.,0.]) + 1e-4*np.random.randn(ndim) for i in range(nwalkers)]
    
    with Pool() as pool:
        sampler_no_offset = emcee.EnsembleSampler(nwalkers, ndim, lnp, pool=pool)
        start = time.time()
        sampler_no_offset.run_mcmc(pos_no_offset, 2000, progress=True)
        
        end = time.time()
        multi_time = end - start
        print("Multiprocessing took {0:.1f} seconds with no offset".format(multi_time))

    pos_with_offset = [np.array([.7,147.09,0.3,-1.,0.]) + 1e-4*np.random.randn(ndim) for i in range(nwalkers)]
    with Pool() as pool:
        sampler_with_offset = emcee.EnsembleSampler(nwalkers, ndim, lnp_M, pool=pool)
        start = time.time()
        sampler_with_offset.run_mcmc(pos_with_offset, 1000, progress=True)
        
        end = time.time()
        multi_time = end - start
        print("Multiprocessing took {0:.1f} seconds with offset".format(multi_time))
    
    # Save txt file
    samples1 = sampler_no_offset.get_chain(discard=200, flat=True)
    samples2 = sampler_with_offset.get_chain(discard=200, flat=True)
    np.savetxt(os.path.join(output_dir, "CPL_IG_01_no_offset.txt"), samples1)
    np.savetxt(os.path.join(output_dir, "CPL_IG_01_with_offset.txt"), samples2)

    print("Done.")