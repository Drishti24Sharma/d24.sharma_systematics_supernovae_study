#Change A and B to w0 and wa in the GEN chain files
# This script transforms the GEN chain files from the Progenitor_X systematics, which uses A and B parameters,
# to the CPL model, which uses w0 and wa parameters.
# The transformation is based on the following equations:
# w0 = (2 * A / (3 * B) - 1) / (1 - Om0)
# wa = (2. * A / B) * (2. / (3. * B) - 1.) / (1. - Om0) \
#      - ((2. * A) / (3. * B) - 1) * ((2. * A / B) - 3. * Om0) / ((1. - Om0)**2)

# this is same for all other systematics.
# Importing necessary libraries
import os
import numpy as np
Om0 = 0.3

def transform_gen_chain(input_path, output_path):
    """
    Replaces A and B columns with w0 and wa in the general model MCMC chain.
    Keeps all other original columns unchanged.
     columns = [h, r_d, Ωₘ, A, B]
    Outputs: same structure, but columns 3 and 4 become w0 and wa.
    """
    Om0 = 0.3
    data = np.loadtxt(input_path)
    A, B = data[:, 3], data[:, 4]
        # w0 expression
    w0 = (2 * A / (3 * B) - 1) / (1 - Om0)

    wa = (2. * A / B) * (2. / (3. * B) - 1.) / (1. - Om0) \
     - ((2. * A) / (3. * B) - 1.) * ((2. * A / B) - 3. * Om0) / ((1. - Om0)**2)



    # Replacing A and B with w0 and wa
    data[:, 3] = w0
    data[:, 4] = wa

    # Saving modified data
    np.savetxt(output_path, data)

## Displaying header samples for input and output files
    print("Header sample:input", np.loadtxt(input_path, max_rows=5))
    print("Header sample:output", np.loadtxt(output_path, max_rows=5))

# Transforming the GEN chain files
transform_gen_chain("GEN_progenitor_X_no_offset.txt",   "Progenitor_X_GEN(to)CPL_w0wa_no_offset.txt")
transform_gen_chain("GEN_progenitor_X_with_offset.txt", "Progenitor_X_GEN(to)CPL_w0wa_with_offset.txt")
print("Done transformation")