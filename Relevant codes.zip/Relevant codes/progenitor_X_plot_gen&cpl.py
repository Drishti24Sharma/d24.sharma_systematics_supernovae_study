#this script plots the w0 vs wa contours for CPL model and GEN model both with and without offset for w0-wa plane
# It uses the getdist library to create the plots and save them in high resolution. 
# It also includes an arrow indicating the difference between the two models
import numpy as np
from getdist import MCSamples, plots
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import seaborn as sns

# === Load chains ===
cpl_nominal_data = np.loadtxt("CPL_progX_01_no_offset.txt")
cpl_sys_data     = np.loadtxt("CPL_progX_01_with_offset.txt")
gen_nominal_data = np.loadtxt("Progenitor_X_GEN(to)CPL_w0wa_no_offset.txt")
gen_sys_data     = np.loadtxt("Progenitor_X_GEN(to)CPL_w0wa_with_offset.txt")

# === Parameter names and labels ===
param_names = ["h", "r_d", "Omega_m0", "w0", "wa"]
labels = ["h", "r_d", "Omega_m0", "w0", "wa"]

# === Nice colors from seaborn ===
sns.set(style="white")
palette = sns.color_palette("colorblind")
blue, green, orange, red, purple, black = palette[0], palette[2], palette[3], palette[4], palette[5], palette[6]

# === MCMC samples ===
cpl_nominal = MCSamples(samples=cpl_nominal_data, names=param_names, labels=labels, label="CPL", ignore_rows=0)
cpl_sys     = MCSamples(samples=cpl_sys_data,     names=param_names, labels=labels, label="CPL + prog-X1(0.1)SYS", ignore_rows=0)
gen_nominal = MCSamples(samples=gen_nominal_data, names=param_names, labels=labels, label="General", ignore_rows=0)
gen_sys     = MCSamples(samples=gen_sys_data,     names=param_names, labels=labels, label="General + progX(0.1)SYS", ignore_rows=0)

# === Smooth contours ===
cpl_nominal.smooth_scale_2D = 0.3
cpl_sys.smooth_scale_2D = 0.3
gen_nominal.smooth_scale_2D = 0.3
gen_sys.smooth_scale_2D = 0.3

# === Setup plotter ===
g = plots.get_subplot_plotter(width_inch=6, subplot_size=3.0)


g.settings.figure_legend_frame = False
g.settings.alpha_filled_add = 0.4
g.settings.axes_fontsize = 14
g.settings.legend_fontsize = 11
g.settings.linewidth_contour = 2.0

# === Plot contours ===
g.plot_2d([cpl_nominal], ['w0', 'wa'], filled=True, colors=["#669dc2"])   # Soft blue
g.plot_2d([gen_nominal], ['w0', 'wa'], filled=True, colors=["#fc8d62"])  # Soft orange
g.plot_2d([cpl_sys], ['w0', 'wa'], filled=False, line_args=[{'color': "#8da0cb", 'linestyle': '--'}])  # Purple dashed contour
g.plot_2d([gen_sys], ['w0', 'wa'], filled=False, line_args=[{'color': "#e78ac3", 'linestyle': '--'}])  # Pink dashed contour


# === Axes from getdist, not plt.gca() ===
fig = g.fig
ax = g.subplots[0][0]
ax.set_xlim(-1.5, -0.6)
ax.set_ylim(-1.5, 1.2)
ax.axhline(0, color='gray', linestyle='dotted')
ax.axvline(-1, color='gray', linestyle='dotted')
# Corrected LaTeX math text - single backslash inside raw string, math mode for \mathbf
ax.text(0.97, 0.97, r"$\mathbf{}$", transform=ax.transAxes, fontsize=14, ha='right', va='top')

from matplotlib.patches import Patch, FancyArrowPatch

import matplotlib.lines as mlines

# === Define the scales you're using ===
scale_cpl = 2.0
scale_gen = 3.0

# === Create proxy arrow artists for legend ===
arrow_cpl = mlines.Line2D([], [], color="#3f1fb4", marker=r'$\rightarrow$', markersize=15, linestyle='None', lw=2)
arrow_gen = mlines.Line2D([], [], color="#a02c2c", marker=r'$\rightarrow$', markersize=15, linestyle='None', lw=2)

# === Legend with dynamic scales in label ===
legend_elements = [
    Patch(facecolor="#669dc2", edgecolor='black', label='CPL'),
    Patch(facecolor="#fc8d62", edgecolor='black', label='General'),
    Patch(facecolor='none', edgecolor="#8da0cb", linestyle='--', label='CPL + prog-X1(0.1)'),
    Patch(facecolor='none', edgecolor="#e78ac3", linestyle='--', label='General + prog-X1(0.1)'),
    arrow_cpl,
    arrow_gen
]

legend_labels = [
    'CPL',
    'General',
    'CPL + prog-X1(0.1))',
    'General + prog-X1(0.1)',
    f'Arrow_CPL(scale={scale_cpl})',
    f'Arrow_General(scale={scale_gen})'
]

ax.legend(handles=legend_elements, labels=legend_labels, loc='lower left', frameon=False)

# === Function to add scaled arrows ===
def add_scaled_arrow(mean_from, mean_to, color, ax, scale=1.0):
    dx, dy = np.array(mean_to) - np.array(mean_from)
    scaled_to = np.array(mean_from) + scale * np.array([dx, dy])
    ax.annotate(
        '', xy=scaled_to, xytext=mean_from,
        arrowprops=dict(arrowstyle='<->', lw=2, color=color, mutation_scale=15)
    )

# === Extract mean values for (w0, wa) ===
mean_cpl_nominal = cpl_nominal.getMeans()[3:5]
mean_cpl_sys     = cpl_sys.getMeans()[3:5]
mean_gen_nominal = gen_nominal.getMeans()[3:5]
mean_gen_sys     = gen_sys.getMeans()[3:5]

# === Draw arrows with custom colors and scales ===
add_scaled_arrow(mean_cpl_nominal, mean_cpl_sys, "#3f1fb4", ax, scale=scale_cpl)  # Dark blue arrow for CPL
add_scaled_arrow(mean_gen_nominal, mean_gen_sys, "#a02c2c", ax, scale=scale_gen)  # Dark red arrow for General

# === Compute and save deltas ===
delta_cpl = np.array(mean_cpl_sys) - np.array(mean_cpl_nominal)
delta_gen = np.array(mean_gen_sys) - np.array(mean_gen_nominal)

delta_text = (
    f"CPL: Δw0 = {delta_cpl[0]:+.4f}, Δwa = {delta_cpl[1]:+.4f}\n"
    f"General: Δw0 = {delta_gen[0]:+.4f}, Δwa = {delta_gen[1]:+.4f}"
)
print(delta_text)

with open("prog_x1_w0_wa_deltas.txt", "w", encoding="utf-8") as f:
    f.write(delta_text)

# === Save using the correct figure ===
fig.savefig("prog_x1_w0_wa_contours.pdf", dpi=600, bbox_inches='tight')
fig.savefig("prog_x1_w0_wa_contours.png", dpi=600, bbox_inches='tight')
plt.show()

