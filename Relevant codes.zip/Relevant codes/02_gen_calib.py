#___________________________CPL_CALIBRATION____________________________________#
#import mpi4py
import os
os.environ["OMP_NUM_THREADS"] = "1"
import time
import numpy as np
import scipy.optimize as opt
import scipy.stats
import scipy.linalg as la
from scipy import constants
import matplotlib.pyplot as pl
import corner
import emcee
from matplotlib.ticker import MaxNLocator
#from emcee.utils import MPIPool
import sys
import tqdm
#from emcee.utils import MPIPool
from new_model import *
import matplotlib
import matplotlib.pyplot as plt
import pandas as pd
import getdist
from getdist import plots, MCSamples
output_dir = '02_cal_gen_results'
os.makedirs(output_dir,exist_ok= True )

zdesi, meandesi = np.loadtxt('data/desi_dr2_2025_gaussian_bao_ALL_GCcomb_mean.txt', usecols=(0, 1), unpack=True)
Ndesi = len(zdesi)
covdesi_dr2 = np.loadtxt('data/desi_dr2_2025_gaussian_bao_ALL_GCcomb_cov.txt')[:Ndesi, :Ndesi]
covinvd2 = np.linalg.inv(covdesi_dr2)

covar = os.path.join("data/Pantheon+SH0ES_STAT+SYS.cov")
data = pd.read_csv('data/Pantheon+SH0ES.dat',sep=r'\s+')
cov  = np.loadtxt('data/Pantheon+SH0ES_STAT+SYS.cov')
covarray = cov[1:len(cov)]    
covmat = covarray.reshape(1701,1701) 

z_cmb = data['zHD']
mu = data['MU_SH0ES']
m = data['m_b_corr']
origlen = len(data)

ww = (data['zHD']>0.01) 
zCMB = data['zHD'][ww] 
zHEL = data['zHEL'][ww]
mu_obs = data['MU_SH0ES'][ww]
m_obs = data['m_b_corr'][ww]
is_calibrator = data['IS_CALIBRATOR'][ww]
cepheid_distance = data['CEPH_DIST'][ww]

f = open(covar)
line = f.readline()
n = int(len(zCMB))
C = np.zeros((n,n))
ii = -1
jj = -1
mine = 999
maxe = -999
for i in range(origlen):
    jj = -1
    if ww[i]:
        ii += 1
    for j in range(origlen):
        if ww[j]:
            jj += 1
        val = float(f.readline())
        if ww[i]:
            if ww[j]:
                C[ii,jj] = val
f.close()

newcov = C
covariance = np.array(newcov)
inv_cov = np.linalg.inv(covariance)

zcmb = zCMB.to_numpy()
zhel = zHEL.to_numpy()

#--------Simulating data----------
clas_sn = GEN(A= 0.3, B=2./3)

Dl_sim = np.array([clas_sn.D_L_z(z) for z in zcmb])
mu_sim = 5.* np.log10(Dl_sim) + 25



clas_bao = GEN(h=0.7, rd=147.09, Om0=0.3, A= 0.3, B=2./3)
dist_bao = np.array([clas_bao.dvrd(0.295),
        clas_bao.dmrd(0.510),
        clas_bao.dhrd(0.510),
        clas_bao.dmrd(0.706),
        clas_bao.dhrd(0.706),
        clas_bao.dmrd(0.934),
        clas_bao.dhrd(0.934),
        clas_bao.dmrd(1.321),
        clas_bao.dhrd(1.321),
        clas_bao.dmrd(1.484),
        clas_bao.dhrd(1.484),
        clas_bao.dmrd(2.330),
        clas_bao.dhrd(2.330)])



def chiPanthSN(h, rd, Om0, A, B):
    M=0.
    clas = GEN(h, rd, Om0, A, B)
    x = np.vectorize(clas.luminosity_distance_z) 
    mod = 5.* np.log10((1.+zHEL)/(1.+zCMB) * x(zCMB) * c_kms/h) + 25.
    delta = np.array(mu_sim - mod - M)
    D = np.sum(delta.T @ inv_cov @ delta)
    E = np.sum(delta @ inv_cov)
    C = np.sum(inv_cov)
    return D #- B**2 / C


def chiPanthSN_M(h, rd, Om0, A, B):
    M= + 0.02
    clas = GEN(h, rd, Om0, A, B)
    x = np.vectorize(clas.luminosity_distance_z) 
    mod = 5.* np.log10((1.+zHEL)/(1.+zCMB) * x(zCMB) * c_kms/h) + 25.
    #delta = np.array(mu_sim - mod - M)
    
    # Apply the offset only for z_CMB < 0.1
    offset_applied = np.where(zCMB < 0.1, M, 0)  # Apply M where z_CMB < 0.1
    delta = np.array(mu_sim - mod - offset_applied)  # Apply the conditional offset
    
    D = np.sum(delta.T @ inv_cov @ delta)
    E = np.sum(delta @ inv_cov)
    C = np.sum(inv_cov)
    return D # - B**2 / C


def chidesi(h, rd, Om0, A, B):
    clas = GEN(h, rd, Om0, A,B)
    zz12 = np.array([clas.dvrd(0.295),
        clas.dmrd(0.510),
        clas.dhrd(0.510),
        clas.dmrd(0.706),
        clas.dhrd(0.706),
        clas.dmrd(0.934),
        clas.dhrd(0.934),
        clas.dmrd(1.321),
        clas.dhrd(1.321),
        clas.dmrd(1.484),
        clas.dhrd(1.484),
        clas.dmrd(2.330),
        clas.dhrd(2.330),
    ]) -  dist_bao
    return np.dot(zz12, np.dot(covinvd2, zz12))

def chird(rd):
    return (rd - 147.09)**2/0.27**2

def chiom(Om0):
    return (Om0 - 0.3)**2/0.007**2

def chi2(h, rd, Om0, A, B):
    return chidesi(h, rd, Om0, A, B) + chiPanthSN(h, rd, Om0, A, B) + chird(rd) + chiom(Om0)

def lnlike(h, rd, Om0, A, B):
    return -0.5 * chi2(h, rd, Om0, A, B) 

def lnprior(h, rd, Om0, A, B):
    if 0.3 < h < 1.2 and 100. < rd < 200. and 0.0 < Om0 < 1. and 0.0 < A < 1. and 0.4 < B < 0.8 :
        return 0.0
    return -np.inf

def lnprob(theta):
    h, rd, Om0, A, B = theta
    lp = lnprior(h, rd, Om0, A, B)
    if not np.isfinite(lp):
        return -np.inf
    ll = lnlike(h, rd, Om0, A, B)
    return lp + ll if np.isfinite(ll) and not np.isnan(ll) and not np.iscomplex(ll) else -np.inf

def ff(theta): return -2. * lnprob(theta)
def lnp(theta): return lnprob(theta)

print('chi2 is',chi2(0.7,147.09,0.3,0.3,2./3))

def chi2_M(h, rd, Om0, A, B):
    return chidesi(h, rd, Om0, A, B) + chiPanthSN_M(h, rd, Om0, A, B) + chird(rd) + chiom(Om0)

def lnlike_M(h, rd, Om0, A, B):
    return -0.5 * chi2_M(h, rd, Om0, A, B)

def lnprob_M(theta):
    h, rd, Om0, A, B = theta
    lp = lnprior(h, rd, Om0, A, B)
    if not np.isfinite(lp):
        return -np.inf
    ll = lnlike_M(h, rd, Om0, A, B)
    return lp + ll if np.isfinite(ll) and not np.isnan(ll) and not np.iscomplex(ll) else -np.inf

def ff_M(theta): return -2. * lnprob_M(theta)
def lnp_M(theta): return lnprob_M(theta)

print('chi2_M is', chi2_M(0.7,147.09,0.3,0.3,2./3))


#_________________PLOT delta_mu vs zcmb_________________#




# Main block
if __name__ == '__main__':
    import multiprocessing
    from multiprocessing import Pool
    multiprocessing.set_start_method('spawn')

    result_no_offset = opt.minimize(ff, [0.7, 147.09, 0.3, 0.3, 2./3])
    h_ml_no_offset, rd_ml_no_offset, Om0_ml_no_offset, A_ml_no_offset, B_ml_no_offset = result_no_offset['x']
    print("""Maximum likelihood result(no offset):
        #      h = {0} (truth: {1})
        #     rd = {2} (truth: {3})
        #     Om = {4} (truth: {5})
        #     A = {6} (truth: {7})
        #     B = {8} (truth: {9})""".format(h_ml_no_offset, 0.7, rd_ml_no_offset, 147.09, Om0_ml_no_offset, 0.3, A_ml_no_offset, 0.3, B_ml_no_offset, 2./3))


    result_offset = opt.minimize(ff_M, [0.7, 147.09, 0.3, 0.3, 2./3])
    h_ml_offset, rd_ml_offset, Om0_ml_offset, A_ml_offset, B_ml_offset = result_offset['x']
    print("""Maximum likelihood result(offset):
        #      h = {0} (truth: {1})
        #     rd = {2} (truth: {3})
        #     Om = {4} (truth: {5})
        #     A = {6} (truth: {7})
        #     B = {8} (truth: {9})""".format(h_ml_offset, 0.7, rd_ml_offset, 147.09, Om0_ml_offset, 0.3, A_ml_offset, 0.3, B_ml_offset, 2./3))

    ndim, nwalkers =5, 200
    
    pos_no_offset = [np.array([0.7,147.09,0.3,0.3,2./3]) + 1e-4*np.random.randn(ndim) for i in range(nwalkers)]
    
    with Pool() as pool:
        sampler_no_offset = emcee.EnsembleSampler(nwalkers, ndim, lnp, pool=pool)
        start = time.time()
        sampler_no_offset.run_mcmc(pos_no_offset, 2000, progress=True)
        
        end = time.time()
        multi_time = end - start
        print("Multiprocessing took {0:.1f} seconds with no offset".format(multi_time))

    pos_with_offset = [np.array([.7,147.09,0.3,0.3,2./3]) + 1e-4*np.random.randn(ndim) for i in range(nwalkers)]
    with Pool() as pool:
        sampler_with_offset = emcee.EnsembleSampler(nwalkers, ndim, lnp_M, pool=pool)
        start = time.time()
        sampler_with_offset.run_mcmc(pos_with_offset, 2000, progress=True)
        
        end = time.time()
        multi_time = end - start
        print("Multiprocessing took {0:.1f} seconds with offset".format(multi_time))
    
    # Save txt file
    samples1 = sampler_no_offset.get_chain(discard=200, flat=True)
    samples2 = sampler_with_offset.get_chain(discard=200, flat=True)
    np.savetxt(os.path.join(output_dir, "GEN(+)_CAL(final)_01_no_offset.txt"), samples1)
    np.savetxt(os.path.join(output_dir, "GEN(+)_CAL_01(final)_with_offset.txt"), samples2)
        # --- Compute mean and std from MCMC
    means_no_offset = np.mean(samples1, axis=0)    
    stds_no_offset = np.std(samples1, axis=0)

    means_with_offset = np.mean(samples2, axis=0)
    stds_with_offset = np.std(samples2, axis=0)

# --- Save to CSV
    param_names = ["h", "rd", "Om0", "A", "B"]

# Save NO OFFSET results
    df_no_offset = pd.DataFrame({
        "parameter": param_names,
        "mle_value": result_no_offset['x'],
        "mcmc_mean": means_no_offset,
        "mcmc_std": stds_no_offset
    })
    df_no_offset.to_csv(os.path.join(output_dir, "GEN(+)_CALIB(final)_02_no_offset_params.csv"), index=False)

# Save WITH OFFSET results
    df_with_offset = pd.DataFrame({
        "parameter": param_names,
        "mle_value": result_offset['x'],
        "mcmc_mean": means_with_offset,
        "mcmc_std": stds_with_offset
    })
    df_with_offset.to_csv(os.path.join(output_dir, "GEN(+)_CALIB(final)_02_with_offset_params.csv"), index=False)

    print("Saved all results successfully.")

    print("Done.")

