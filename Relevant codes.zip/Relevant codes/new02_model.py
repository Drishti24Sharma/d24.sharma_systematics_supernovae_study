##---- this is the latest model sent by purba di---######
import numpy as np
from scipy.differentiate import derivative
from scipy.integrate import odeint
from scipy import interpolate
from scipy.special import hyp2f1
from scipy.integrate import quad
from scipy.interpolate import splrep, splev, UnivariateSpline
#from scipy. import derivative
from scipy.optimize import fsolve
#from .transfer_func import *
#import transfer_func as tf
######################################

c_kms = 2997.98

class LCDM(object):
    def __init__(self, h=0.7, Om0=0.3, rd=147.09, sigma8=0.8, Ob0=0.045, Or0=5*10**(-5), ns=0.96, As=3.1, k=0.01):
        self.h = float(h)
        self.Om0 = float(Om0)
        self.rd = float(rd)
        self.Ob0 = float(Ob0)
        self.Or0 = float(Or0)
        self.ns = float(ns)
        self.sigma8 = float(sigma8)
        self.As=float(As)
        self.k = float(k)

    def hubble_normalized_z(self, z):
        return np.sqrt(self.Om0*(1.+z)**3. + self.Or0*(1+z)**4 + (1.-self.Om0-self.Or0))

    def inverse_hubble_normalized_z(self, z):
        return 1./self.hubble_normalized_z(z)

    def hubble_normalized_a(self, a):
        return self.hubble_normalized_z(1./a-1)

    def hubble_prime_normalized_a(self, a):
        return derivative(self.hubble_normalized_a, a, dx=1e-6)

    def comoving_distance_z(self, z1):
        return quad(self.inverse_hubble_normalized_z, 0, z1)[0]

    def angular_diameter_distance_z(self, z):
        d_A = self.comoving_distance_z(z)/(1.+z)
        return d_A

    def luminosity_distance_z(self, z):
        d_l = self.comoving_distance_z(z)*(1.+z)
        return d_l

    def D_H(self):
        return c_kms / self.h
        
    def D_L_z(self, z):
        return self.comoving_distance_z(z)*(1.+z) * self.D_H()

    def hrd(self):
        return self.h *  self.rd


    def dM(self,z):
        return self.comoving_distance_z(z)/self.h * c_kms

    def dH(self,z):
        return self.inverse_hubble_normalized_z(z)/self.h * c_kms

    def dV(self,z):
        return ( z * self.comoving_distance_z(z)**2. / self.hubble_normalized_z(z))**(1./3.) * c_kms /self.h

    def dA(self, z):
        return self.angular_diameter_distance_z(z)/self.h * c_kms



    def dmrd(self,z):
        return self.comoving_distance_z(z)/self.hrd() * c_kms

    def dhrd(self,z):
        return self.inverse_hubble_normalized_z(z)/self.hrd() * c_kms

    def dvrd(self,z):
        return ( z * self.comoving_distance_z(z)**2. / self.hubble_normalized_z(z))**(1./3.) * c_kms /self.hrd()

    def dArd(self, z):
        return self.angular_diameter_distance_z(z)/self.hrd() * c_kms
        
    def z_decoupling(self):
        g1 = (0.0783*(self.Ob0*self.h**2)**(-0.238))/(1+39.5*(self.Ob0*self.h**2)**(0.763))
        g2 = 0.560/(1+21.1*(self.Ob0*self.h**2)**1.81)
        return 1048*(1.+0.00124*(self.Ob0*self.h**2)**(-0.738))*(1+g1*(self.Om0*self.h**2)**g2)

    def z_drag_epoch(self):
        b1 = 0.313*((self.Om0*self.h**2)**(-0.419))*(1+0.607*(self.Om0*self.h**2)**0.674)
        b2 = 0.238*(self.Om0*self.h**2)**0.223
        return 1291.*(self.Om0*self.h**2)**0.251*(1+b1*(self.Om0*self.h**2)**b2)/(1+0.659*(self.Om0*self.h**2)**0.828)

    def sound_horizon(self, z):
        if z < self.z_decoupling():
            raise ValueError(
                'Redshift should be greater than decoupling redshift')
        R1 = 31500*(self.Ob0*self.h**2)*(2.7255/2.7)**(-4)*1/(1.+z)

        def integrand1(a):
            return 1./(np.sqrt(3*(1+R1))*self.hubble_normalized_a(a)*a**2)
        return quad(integrand1, 0., 1./(1+z))[0]

    def cmb_shift_parameter(self):
        return np.sqrt(self.Om0)*(1+self.z_decoupling())*self.angular_diameter_distance_z(self.z_decoupling())

    def acoustic_length(self):
        z_star = self.z_decoupling()
        return np.pi*self.angular_diameter_distance_z(z_star)*(1+z_star)/self.sound_horizon(z_star)

    def theta_star(self):
        z_star = 1090.
        r_star = self.rd / 1.018
        DM_star = self.angular_diameter_distance_z(z_star) * (1+z_star) * self.D_H()
        return r_star/DM_star


class CPL(LCDM):
    def __init__(self, h=0.7, Om0=0.3, w0=-1., wa=0., rd=147.09, sigma8=0.8, Ob0=0.045, Or0=5*10**(-5), ns=0.96, As=3.1, k=0.01):
        self.h = float(h)
        self.Om0 = float(Om0)
        self.w0 = float(w0)
        self.wa = float(wa)
        self.rd = float(rd)
        self.Ob0 = float(Ob0)
        self.Or0 = float(Or0)
        self.ns = float(ns)
        self.sigma8 = float(sigma8)
        self.As=float(As)
        self.k = float(k)
        
    def hubble_normalized_z(self, z):
        return np.sqrt(self.Om0*(1+z)**3 + self.Or0*(1+z)**4 + (1.-self.Om0-self.Or0)*(1+z)**(3.*(1+self.w0+self.wa))*np.exp(-3.*self.wa*z/(1+z)))

    
#general model
class GEN(LCDM):
    def __init__(self, h=0.7, Om0=0.3, A=0.3, B=2./3, rd=147.09, sigma8=0.8, Ob0=0.045, Or0=5 * 10 ** (-5), ns=0.96, As=3.1, k=0.01):
        #super().__init__(h, rd, Om0, sigma8, Ob0, Or0, ns, As, k)
        self.h = float(h)
        self.Om0 = float(Om0)
        self.A = float(A)
        self.B = float(B)
        self.rd = float(rd)
        self.Ob0 = float(Ob0)
        self.Or0 = float(Or0)
        self.ns = float(ns)
        self.sigma8 = float(sigma8)
        self.As=float(As)
        self.k = float(k)
    
    
    def hubble_normalized_z(self, z):
        
        return np.sqrt(self.A*(1+z)**(2./self.B) + self.Or0*(1+z)**4 + (1.-self.Or0-self.A))
    
    '''#modified for the warnings

    def hubble_normalized_z(self, z):
        hz2 = self.A*(1+z)**(2./self.B) + self.Or0*(1+z)**4 + (1 - self.Or0 - self.A)
        return np.sqrt(np.maximum(hz2, 0))  # Avoid sqrt of negative numbers

    def inverse_hubble_normalized_z(self, z):
        hz = self.hubble_normalized_z(z)
        return np.where(hz > 0, 1./hz, np.inf)

    def luminosity_distance_z(self, z):
        result, _ = quad(self.inverse_hubble_normalized_z, 0, z, limit=200)
        return result

    def distance_modulus(self, z):
        dl = (1 + z) * self.luminosity_distance_z(z) * 2997.9 / self.h
        return 5 * np.log10(np.maximum(dl, 1e-10)) + 25  # Avoid log(0)'''
    
print("Done")