# This script plots the A vs B contours for the Progenitor-X1 model with and without offset.
# It uses the getdist library to create the plots and save them in high resolution.     
# It also includes an arrow indicating the difference between the two samples.
import numpy as np
import os
import matplotlib.pyplot as plt
from getdist import plots, MCSamples

# Output folder
#output_dir = "mcmc_CPL_CAL_results"
#os.makedirs(output_dir, exist_ok=True)
output_dir = '02_GEN_prog_X_results'
os.makedirs(output_dir,exist_ok= True )


# Load chains
#samples_no_offset = np.loadtxt("CAL_no_offset.txt")
#samples_with_offset = np.loadtxt("correct_CPL_CAL_with_offset.txt")

samples_no_offset = np.loadtxt('GEN_progenitor_X_no_offset.txt')
samples_with_offset = np.loadtxt('GEN_progenitor_X_with_offset.txt')



# Parameter names and LaTeX labels
param_names = ["h", "r_d", "Omega_m0", "A", "B"]
labels = [r"h", r"r_d", r"\Omega_{m0}", r"A", r"B"]

# Create MCSamples
samples1 = MCSamples(samples=samples_no_offset, names=param_names, labels=labels)
samples2 = MCSamples(samples=samples_with_offset, names=param_names, labels=labels)

# Plot setup
g = plots.get_subplot_plotter()
g.settings.axes_fontsize = 14
g.settings.legend_fontsize = 1
g.settings.line_styles = ['-', '--']
g.settings.linewidth_contour = 2.0
g.settings.alpha_filled_add = 0.3  # slight transparency so overlapping is visible
#g.settings.smooth_scale_2D = 0.3   # lower smoothing to better show structure
samples1.smooth_scale_2D = 0.3
samples2.smooth_scale_2D = 0.3

# Assign strong custom colors
colors = ['#1f77b4', '#d62728']  # Blue and red (strong contrast)

# Plot with filled contours and visible lines
g.plot_2d([samples1, samples2], "A", "B", filled=True, colors=colors)
#g.add_legend(["No Offset", "With Offset"], legend_loc="upper right")
g.add_legend(["mcmc_gen", "prog-X1(0.1)"], legend_loc="upper right",fontsize=5)


# Adjust axis limits for callibration of cpl
#plt.gca().set_xlim(-1, 1)
#plt.gca().set_ylim(0, 2.3)

#axis limit fir progenitor cpl
plt.gca().set_xlim(0.2,0.5)
plt.gca().set_ylim(0.6,0.8)

# Add title and confidence level label
plt.title("A vs B Contour Comparison Progenitor-X1", fontsize=10)

#Get means
means_no_offset = samples1.getMeans()
means_with_offset = samples2.getMeans()

# Coordinates
x0, y0 = means_no_offset[param_names.index('A')], means_no_offset[param_names.index('B')]
dx = means_with_offset[param_names.index('A')] - x0
dy = means_with_offset[param_names.index('B')] - y0

# Add arrow to plot
ax = g.subplots[0][0]  # Access subplot for A vs B
arrow_scale = 2
ax.annotate(
    '', 
    xy=(x0 + arrow_scale * dx, y0 + arrow_scale * dy), 
    xytext=(x0, y0),
    arrowprops=dict(
        arrowstyle='<->',
        color='black',
        lw=1.,
        mutation_scale= 5 # scales arrow head
    )
)
# Save high-res image
output_path = os.path.join(output_dir, "B_vs_A_gen_prog-X1.png")
g.export(output_path, dpi=500)
print(f"✅ Plot saved to: {output_path}")

