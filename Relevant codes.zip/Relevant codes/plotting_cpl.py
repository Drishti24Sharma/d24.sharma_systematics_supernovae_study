#this script plots the w0 vs wa contours for CPL model with and without offset
# It uses the getdist library to create the plots and save them in high resolution. 
# It also includes an arrow indicating the difference between the two samples.
import numpy as np
import os
import matplotlib.pyplot as plt
from getdist import plots, MCSamples
import os

print(os.getcwd())

# Output folder
#output_dir = "mcmc_CPL_CAL_results"
#os.makedirs(output_dir, exist_ok=True)
output_dir = '01_ProgX_cpl_results'
os.makedirs(output_dir,exist_ok= True )


# Load chains
#samples_no_offset = np.loadtxt("CAL_no_offset.txt")
samples_with_offset = np.loadtxt('CPL_progX_01_with_offset.txt')

samples_no_offset = np.loadtxt('CPL_progX_01_no_offset.txt')
#samples_with_offset = np.loadtxt('prog_cpl_samples.txt')



# Parameter names and LaTeX labels
param_names = ["h", "r_d", "Omega_m0", "w0", "wa"]
labels = [r"h", r"r_d", r"\Omega_{m0}", r"w_0", r"w_a"]

# Create MCSamples
samples1 = MCSamples(samples=samples_no_offset, names=param_names, labels=labels)
samples2 = MCSamples(samples=samples_with_offset, names=param_names, labels=labels)

# Plot setup
g = plots.get_subplot_plotter()
g.settings.axes_fontsize = 14
g.settings.legend_fontsize = 1
g.settings.line_styles = ['-', '--']
g.settings.linewidth_contour = 2.0
g.settings.alpha_filled_add = 0.3  # slight transparency so overlapping is visible
#g.settings.smooth_scale_2D = 0.3   # lower smoothing to better show structure
samples1.smooth_scale_2D = 0.3
samples2.smooth_scale_2D = 0.3

# Assign strong custom colors
colors = ['#1f77b4', '#d62728']  # Blue and red (strong contrast)

# Plot with filled contours and visible lines
g.plot_2d([samples1, samples2], "w0", "wa", filled=True, colors=colors)
#g.add_legend(["No Offset", "With Offset"], legend_loc="upper right")
g.add_legend(["No Offset", "prog-X1 (0.1)"], legend_loc="lower left",fontsize=1.)


# Adjust axis limits for callibration of cpl
#plt.gca().set_xlim(-1, 1)
#plt.gca().set_ylim(0, 2.3)

#axis limit fir progenitor cpl
plt.gca().set_xlim(-1.5,-0.5)
plt.gca().set_ylim(-1.6,1.2)

# Add title and confidence level label
plt.title("w₀ vs wₐ Contour Comparison Progenitor X1", fontsize=10)
#plt.gca().text(-2.45, 2.7, "68% & 95% CL", fontsize=12, style='italic', color='black')

#Get means
means_no_offset = samples1.getMeans()
means_with_offset = samples2.getMeans()

# Coordinates
x0, y0 = means_no_offset[param_names.index('w0')], means_no_offset[param_names.index('wa')]
dx = means_with_offset[param_names.index('w0')] - x0
dy = means_with_offset[param_names.index('wa')] - y0

# Add arrow to plot
ax = g.subplots[0][0]  # Access subplot for w0 vs wa
arrow_scale = 2             # Scale factor for arrow length
print(f"Arrow from ({x0:.3f}, {y0:.3f}) to ({x0 + dx*arrow_scale:.3f}, {y0 + dy*arrow_scale:.3f})")

ax.annotate(
    '', 
    xy=(x0 + arrow_scale * dx, y0 + arrow_scale * dy), 
    xytext=(x0, y0),
    arrowprops=dict(
        arrowstyle='<->',
        color='black',
        lw=1.,
        mutation_scale= 5 # scales arrow head
    )
)

# Save high-res image
output_path = os.path.join(output_dir, "01_wa_vs_w0_cpl_ProgX.png")
g.export(output_path, dpi=500)
print(f"✅ Plot saved to: {output_path}")
